#include "Controller.h"
#include <iostream>

int main(int argc, char **argv) {
    Controller cont;
    cont.letTheGameBegin(argc, argv);
}
