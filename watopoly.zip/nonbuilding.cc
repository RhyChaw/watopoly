#include "nonbuilding.h"

using namespace std;

nonbuilding::nonbuilding(int ID, string name) 
	: Cell{ID, name}
{}
