#include "Gym.h"
#include "Player.h"
#include <iostream>

using namespace std;

const int MIN_ROLL = 1;
const int MAX_ROLL = 6;
const int OWN_1 = 4;
const int OWN_2 = 10;

Gym::Gym(int ID, string name, int costToBuy, char owner)
	: Building(ID, name, costToBuy, owner)
{}

Gym::~Gym() {}

int Gym::calculateFee(int diceRoll) const {
    if (getOwner() == nullptr) {
        return 0;
    }
    
    int gymCount = getOwnerGymCount();
    
    if (gymCount == 1) {
        return diceRoll * 4; 
    } else if (gymCount == 2) {
        return diceRoll * 10; 
    }
    
    return 0;
}

void Gym::setRoll(int n){
    roll = n;
}

int Gym::getOwnerGymCount() const {
    Player* ownerPlayer = getOwnerPlayer();
    if (!ownerPlayer) return 0;
    return ownerPlayer->getOwnedGyms();
}

void Gym::currentOn(Player* player) {
    Player* ownerPlayer = getOwnerPlayer();
    
    if (!ownerPlayer) {
        // No owner, player can purchase
        std::cout << player->getName() << " landed on unowned gym " << getName() << std::endl;
        // Purchase logic
    } else if (ownerPlayer != player) {
        // Another player owns this gym, pay fee
        int diceRoll = roll; // Use the stored roll value
        int fee = calculateFee(diceRoll);
        
        std::cout << player->getName() << " pays " << fee << " to " 
                  << ownerPlayer->getName() << " for landing on " << getName() << std::endl;
        
        player->changeCash(-fee);
        ownerPlayer->changeCash(fee);
    } else {
        // Player owns this gym
        std::cout << player->getName() << " landed on their own gym " << getName() << std::endl;
    }
}

