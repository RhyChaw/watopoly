#include "building.h"
#include "Player.h"

Building::Building(int ID, std::string name, int price, char owner) 
    : Cell(ID, name), owner{owner}, price{price}, imprLevel{0}, payLevel{0} {
}

std::map<char, Player*> Building::playerRegistry;

void Building::setOwner(char owner) {
   this->owner = owner;
}

void Building::setMortStatus(bool status) {
    mortgageStatus = status;
}

void Building::setImprLevel(int level) {
    imprLevel = level;
}

void Building::setPayLevel(int level) {
    payLevel = level;
}

char Building::getOwner() const {
    return owner;
}

bool Building::getMortStatus() const {
    return mortgageStatus;
}

int Building::getImprLevel() const {
    return imprLevel;
}

int Building::getPayLevel() const {
    return payLevel;
}

int Building::getCostToBuy() const {
    return price;
}

std::string Building::getMonoBlock() const {
    return monopolyBlock;
}

Player* Building::getOwnerPlayer() const {
    // Implementation to find Player by owner character
    // This is just a sketch; you'll need to implement the actual player lookup
    if (owner == ' ') return nullptr;
    
    // You need some way to look up a Player by their symbol
    // Example: return GameController::getInstance()->getPlayerBySymbol(owner);
    return nullptr; // Placeholder
}

void Building::registerPlayer(char symbol, Player* player) {
    playerRegistry[symbol] = player;
}

void Building::clearPlayerRegistry() {
    playerRegistry.clear();
}

Player* Building::getOwnerPlayer() const {
    // If no owner, return nullptr
    if (owner == ' ') {
        return nullptr;
    }
    
    // Look up the player in the registry
    auto it = playerRegistry.find(owner);
    if (it != playerRegistry.end()) {
        return it->second;
    }
    
    // If not found, log a warning and return nullptr
    std::cerr << "Warning: No player found with symbol '" << owner << "'" << std::endl;
    return nullptr;
}
