#ifndef BUILDING_H
#define BUILDING_H
#include <string>
#include "Cell.h"
#include <memory>

class Player;

class Building : public Cell {
    char owner;
    int price;
    bool mortgageStatus = false;
    int imprLevel;
    int payLevel; //almost the same with imprLevel except for gym and resident, this one show how many gym (or res) all own together 
    std::string monopolyBlock;
    static std::map<char, Player*> playerRegistry;

  public:
  Building(int ID, std::string name, int price, char owner, std::string monopolyBlock = "");
  virtual ~Building() = default; // Use default if no special cleanup needed

    void setOwner(char owner);
    void setMortStatus(bool status);
    void setImprLevel(int level);
    void setPayLevel(int level);

    char getOwner() const;
    bool getMortStatus() const;
    int getImprLevel() const;
    int getPayLevel() const;

    int getCostToBuy() const;
    std::string getMonoBlock() const;
    virtual void currentOn(Player* player) = 0; 
    virtual Player* getOwnerPlayer() const; 
    static void registerPlayer(char symbol, Player* player);
    static void clearPlayerRegistry();
};

#endif